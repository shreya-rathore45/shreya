
export enum BinType {
  RECYCLING = 'Recycling (Blue Bin)',
  COMPOST = 'Organic/Compost (Green/Brown Bin)',
  LANDFILL = 'Landfill/General Waste (Grey/Black Bin)',
  HAZARDOUS = 'Hazardous Waste (Special Disposal)',
  ELECTRONICS = 'E-Waste (Recycling Center)'
}

export interface WasteAnalysis {
  itemName: string;
  binType: BinType;
  confidence: number;
  reasoning: string;
  ecoTip: string;
  materialComposition: string;
}

export interface HistoryItem extends WasteAnalysis {
  id: string;
  timestamp: number;
  imageUrl: string;
}
