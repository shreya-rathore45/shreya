
import React, { useState, useEffect } from 'react';
import CameraManager from './components/CameraManager';
import WasteResultCard from './components/WasteResultCard';
import { analyzeWasteImage } from './services/geminiService';
import { WasteAnalysis, HistoryItem } from './types';

const App: React.FC = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentResult, setCurrentResult] = useState<WasteAnalysis | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('ecosort_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('ecosort_history', JSON.stringify(history));
  }, [history]);

  const handleCapture = async (base64: string) => {
    setIsAnalyzing(true);
    setError(null);
    setCurrentResult(null);

    try {
      const result = await analyzeWasteImage(base64);
      setCurrentResult(result);
      
      const newHistoryItem: HistoryItem = {
        ...result,
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        imageUrl: `data:image/jpeg;base64,${base64}`
      };
      setHistory(prev => [newHistoryItem, ...prev].slice(0, 10)); // Keep last 10
    } catch (err) {
      setError("Analysis failed. Please try again with a clearer picture.");
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const clearHistory = () => {
    if (window.confirm("Clear sorting history?")) {
      setHistory([]);
      localStorage.removeItem('ecosort_history');
    }
  };

  return (
    <div className="min-h-screen max-w-2xl mx-auto px-4 py-8 flex flex-col gap-8">
      {/* Header */}
      <header className="flex flex-col items-center gap-2 text-center">
        <div className="w-16 h-16 bg-emerald-500 rounded-3xl flex items-center justify-center shadow-lg shadow-emerald-200 mb-2">
          <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 brand-font tracking-tight">EcoSort AI</h1>
        <p className="text-slate-500 font-medium">Point camera at waste to determine its bin</p>
      </header>

      {/* Main Scanner Section */}
      <main className="space-y-6">
        <CameraManager onCapture={handleCapture} isAnalyzing={isAnalyzing} />

        {error && (
          <div className="p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-sm font-medium flex gap-3">
            <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {error}
          </div>
        )}

        {currentResult && (
          <WasteResultCard 
            analysis={currentResult} 
            onClose={() => setCurrentResult(null)} 
          />
        )}
      </main>

      {/* History Section */}
      {history.length > 0 && (
        <section className="mt-4">
          <div className="flex justify-between items-end mb-4 px-2">
            <div>
              <h3 className="text-lg font-bold text-slate-800 brand-font">Recent Scans</h3>
              <p className="text-sm text-slate-500">Your sorting history</p>
            </div>
            <button 
              onClick={clearHistory}
              className="text-xs font-bold text-slate-400 hover:text-red-500 transition-colors uppercase tracking-widest"
            >
              Clear All
            </button>
          </div>
          
          <div className="space-y-3">
            {history.map((item) => (
              <div 
                key={item.id}
                className="group flex items-center gap-4 p-3 bg-white rounded-2xl border border-slate-100 hover:border-emerald-200 transition-all cursor-pointer shadow-sm hover:shadow-md"
                onClick={() => setCurrentResult(item)}
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-slate-200">
                  <img src={item.imageUrl} alt={item.itemName} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-slate-800 truncate">{item.itemName}</h4>
                  <p className="text-xs font-medium text-slate-400">{item.binType}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-bold text-slate-300 uppercase">
                    {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                  <div className={`w-2 h-2 rounded-full ml-auto mt-2 ${
                    item.binType.includes('Recycling') ? 'bg-blue-500' :
                    item.binType.includes('Compost') ? 'bg-emerald-500' :
                    item.binType.includes('Landfill') ? 'bg-slate-500' :
                    'bg-red-500'
                  }`} />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Footer Branding */}
      <footer className="mt-auto pt-8 pb-4 text-center">
        <p className="text-slate-400 text-xs font-medium uppercase tracking-[0.2em]">
          Powered by Gemini Intelligence
        </p>
      </footer>
    </div>
  );
};

export default App;
