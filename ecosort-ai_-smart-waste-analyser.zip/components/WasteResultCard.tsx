
import React from 'react';
import { WasteAnalysis, BinType } from '../types';

interface WasteResultCardProps {
  analysis: WasteAnalysis;
  onClose: () => void;
}

const WasteResultCard: React.FC<WasteResultCardProps> = ({ analysis, onClose }) => {
  const getBinColor = (type: BinType) => {
    switch (type) {
      case BinType.RECYCLING: return 'bg-blue-600';
      case BinType.COMPOST: return 'bg-emerald-600';
      case BinType.LANDFILL: return 'bg-slate-700';
      case BinType.HAZARDOUS: return 'bg-red-600';
      case BinType.ELECTRONICS: return 'bg-amber-600';
      default: return 'bg-slate-500';
    }
  };

  const getBinIcon = (type: BinType) => {
    switch (type) {
      case BinType.RECYCLING: return '♻️';
      case BinType.COMPOST: return '🍎';
      case BinType.LANDFILL: return '🗑️';
      case BinType.HAZARDOUS: return '⚠️';
      case BinType.ELECTRONICS: return '🔌';
      default: return '❓';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <div className={`${getBinColor(analysis.binType)} p-6 text-white`}>
        <div className="flex justify-between items-start mb-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider opacity-80">Waste Identified</span>
            <h2 className="text-2xl font-bold brand-font">{analysis.itemName}</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-white/20 rounded-lg transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="flex items-center gap-3 bg-white/10 px-4 py-3 rounded-xl border border-white/20">
          <span className="text-2xl">{getBinIcon(analysis.binType)}</span>
          <div>
            <p className="text-sm font-semibold opacity-90">Dispose In:</p>
            <p className="font-bold">{analysis.binType}</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div>
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Analysis Breakdown</h3>
          <p className="text-slate-700 leading-relaxed">{analysis.reasoning}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
            <h4 className="text-xs font-bold text-slate-400 uppercase mb-1">Confidence</h4>
            <p className="text-lg font-bold text-slate-800">{Math.round(analysis.confidence * 100)}%</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
            <h4 className="text-xs font-bold text-slate-400 uppercase mb-1">Materials</h4>
            <p className="text-slate-800 font-medium truncate">{analysis.materialComposition}</p>
          </div>
        </div>

        <div className="bg-emerald-50 p-5 rounded-2xl border border-emerald-100 flex gap-4">
          <div className="text-emerald-500 mt-1">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h4 className="text-sm font-bold text-emerald-800 mb-1">Eco-Tip</h4>
            <p className="text-emerald-700 text-sm leading-snug">{analysis.ecoTip}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WasteResultCard;
