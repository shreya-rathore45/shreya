
import { GoogleGenAI, Type } from "@google/genai";
import { WasteAnalysis, BinType } from "../types";

export const analyzeWasteImage = async (base64Image: string): Promise<WasteAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: "Analyze this image to identify the waste item. Determine the correct disposal category (Recycling, Compost, Landfill, Hazardous, or E-Waste). Be specific about the bin type based on standard global waste management practices."
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          itemName: { type: Type.STRING, description: "The specific name of the item identified." },
          binType: { 
            type: Type.STRING, 
            enum: Object.values(BinType),
            description: "The recommended disposal category." 
          },
          confidence: { type: Type.NUMBER, description: "A confidence score between 0 and 1." },
          reasoning: { type: Type.STRING, description: "Brief explanation of why this bin was chosen." },
          ecoTip: { type: Type.STRING, description: "A short, actionable environmental tip related to this item." },
          materialComposition: { type: Type.STRING, description: "The primary materials this item is made of." }
        },
        required: ["itemName", "binType", "confidence", "reasoning", "ecoTip", "materialComposition"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Empty response from AI");
  
  return JSON.parse(text) as WasteAnalysis;
};
